#ifndef ENCDEC_H
#define ENCDEC_H

#include <unistd.h>    // 用于 pipe 相关函数声明
#include <sys/types.h> // 用于 size_t 等类型

/**
 * 向管道写入数据
 * @param fd 管道文件描述符
 * @param buffer 要写入的数据缓冲区
 * @param size 要写入的字节数
 * @return 成功返回写入的字节数，失败返回-1
 */
int writeToPipe(int fd, const char *buffer, int size);

/**
 * 从管道读取数据
 * @param fd 管道文件描述符
 * @param buffer 存储读取数据的缓冲区
 * @param size 缓冲区大小
 * @return 成功返回读取的字节数，失败返回-1
 */
int readFromPipe(int fd, char *buffer, int size);

/**
 * 统计字符数
 * @param text 要统计的文本
 * @return 字符数量（包含结束符）
 */
int countChar(const char *text);

/**
 * 统计单词数
 * @param text 要统计的文本
 * @return 单词数量（以空白字符分隔）
 */
int countWords(const char *text);

/**
 * 统计行数
 * @param text 要统计的文本
 * @return 行数（以换行符分隔）
 */
int countLines(const char *text);

/**
 * 将字符串转换为小写
 * @param text 要转换的字符串（会被原地修改）
 */
void toLowerCase(char *text);

#endif // ENCDEC_H