#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <ctype.h>
#include "encDec.h"  // 引入自定义头文件，包含 writeToPipe 函数的声明
#include <string.h>

int main(int argc, char *argv[])
{
    // 检查命令行参数数量，确保用户提供了管道文件描述符和要写入的数据
    if (argc != 3)
    {
        fprintf(stderr, "Usage: %s <pipe_fd> <string>\n", argv[0]); // 如果参数错误，打印使用提示
        return 1; // 返回错误代码 1
    }

    // 将管道文件描述符从字符串转换为整数
    int fd = atoi(argv[1]);
    // 获取要写入管道的文本数据
    const char *text = argv[2];

    // 调用 writeToPipe 函数将文本写入管道
    int bytesWritten = writeToPipe(fd, text, strlen(text));
    if (bytesWritten == -1)
    {
        // 如果写入失败，打印错误信息
        fprintf(stderr, "Error writing to pipe\n");
    }
    else
    {
        // 如果写入成功，打印已写入的数据
        printf("Written to pipe: %s\n", text);
    }

    return 0; // 正常结束程序
}
