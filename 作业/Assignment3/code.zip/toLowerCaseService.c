#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "encDec.h" // 引入自定义头文件，包含toLowerCase函数的声明

int main(int argc, char *argv[])
{
    // 检查命令行参数数量，确保用户提供了要转换的小写字符串
    if (argc != 2)
    {
        fprintf(stderr, "Usage: %s <string>\n", argv[0]); // 如果参数错误，打印使用提示
        return 1; // 返回错误代码 1
    }

    // 调用 toLowerCase 函数将输入字符串转换为小写
    toLowerCase(argv[1]);

    // 打印转换后的小写字符串
    printf("Lowercase string: %s\n", argv[1]);

    return 0; // 正常结束程序
}
