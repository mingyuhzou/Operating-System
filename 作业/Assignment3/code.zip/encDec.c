#include "encDec.h"
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>

// 向管道写入数据
int writeToPipe(int fd, const char *buffer, int size)
{
    int bytesWritten = write(fd, buffer, size);  // 写入数据到管道
    if (bytesWritten == -1)
    {
        perror("write failed");  // 写入失败时输出错误信息
    }
    return bytesWritten;  // 返回实际写入的字节数
}

// 从管道读取数据
int readFromPipe(int fd, char *buffer, int size)
{
    int bytesRead = read(fd, buffer, size - 1);  // 从管道读取数据
    if (bytesRead > 0)
    {
        buffer[bytesRead] = '\0';  // 确保字符串以'\0'结尾
    }
    else if (bytesRead == -1)
    {
        perror("read failed");  // 读取失败时输出错误信息
    }
    return bytesRead;  // 返回实际读取的字节数
}

// 计算文本中的字符数
int countChar(const char *text)
{
    return strlen(text);  // 返回字符串的长度
}

// 计算文本中的单词数
int countWords(const char *text)
{
    int count = 0;
    while (*text)
    {
        while (*text && isspace((unsigned char)*text))  // 跳过空格
            text++;
        if (*text)
            count++;  // 找到一个新单词
        while (*text && !isspace((unsigned char)*text))  // 跳过当前单词
            text++;
    }
    return count;  // 返回单词数
}

// 计算文本中的行数
int countLines(const char *text)
{
    int count = 0;
    const char *p = text;

    while (*p)
    {
        if (*p == '\n')  // 检测换行符
            count++;
        p++;
    }

    // 如果文本非空，且最后一个字符不是 '\n'，说明还有一行
    if (p != text && p[-1] != '\n')
        count++;

    return count;  // 返回行数
}

// 将文本转换为小写
void toLowerCase(char *text)
{
    if (text == NULL)
        return;  // 避免空指针错误
    while (*text)
    {
        *text = tolower((unsigned char)*text);  // 转换为小写字母
        text++;
    }
}
