#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <ctype.h>
#include <fcntl.h>
#include "encDec.h" // 引入自定义头文件，包含readFromPipe函数的声明

int main(int argc, char *argv[])
{
    // 检查命令行参数数量，确保用户提供了管道文件描述符
    if (argc != 2)
    {
        fprintf(stderr, "Usage: %s <pipe_fd>\n", argv[0]); // 提示用户正确使用方式
        return 1; // 如果参数错误，则返回错误代码 1
    }

    // 将命令行参数转为整数，表示管道文件描述符
    int fd = atoi(argv[1]);
    char buffer[1024]; // 定义一个缓冲区用来存放从管道读取的数据

    // 调用 readFromPipe 函数读取管道中的数据
    int bytesRead = readFromPipe(fd, buffer, sizeof(buffer));
    if (bytesRead > 0)
    {
        printf("Read from pipe: %s\n", buffer); // 输出从管道读取的内容
    }
    else
    {
        fprintf(stderr, "Error reading from pipe\n"); // 如果读取失败，输出错误信息
    }

    return 0; // 正常结束程序
}
