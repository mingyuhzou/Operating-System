#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "encDec.h" // 引入自定义头文件，包含countWords函数的声明

int main(int argc, char *argv[])
{
    // 检查命令行参数数量，确保用户提供了一个字符串参数
    if (argc != 2)
    {
        fprintf(stderr, "Usage: %s <string>\n", argv[0]); // 提示用户正确使用方式
        return 1; // 如果参数错误，则返回错误代码 1
    }

    // 调用 countWords 函数计算传入字符串中的单词数
    int wordCount = countWords(argv[1]);
    // 输出单词数
    printf("Word count: %d\n", wordCount);

    return 0; // 正常结束程序
}
