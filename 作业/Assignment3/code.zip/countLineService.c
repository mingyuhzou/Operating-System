#include <stdio.h>
#include "encDec.h" // 包含自定义的头文件，定义了countLines函数等
#include <stdlib.h>
#include <ctype.h>

int main(int argc, char *argv[])
{
    // 检查命令行参数数量，确保只有一个参数传入
    if (argc != 2)
    {
        fprintf(stderr, "Usage: %s <string>\n", argv[0]); // 提示正确的用法
        return 1; // 如果参数不对，则返回错误代码 1
    }

    // 调用 countLines 函数来计算传入字符串中的行数
    int lineCount = countLines(argv[1]);
    // 输出行数
    printf("Line count: %d\n", lineCount);

    return 0; // 正常结束程序
}
