#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "encDec.h"

int main(int argc, char *argv[])
{
    // 检查命令行参数数量，确保只有一个参数传入
    if (argc != 2)
    {
        fprintf(stderr, "Usage: %s <string>\n", argv[0]); // 提示正确的用法
        return 1; // 如果参数不对，则返回错误代码 1
    }

    // 调用 countChar 函数来计算传入字符串的字符数
    int charCount = countChar(argv[1]);
    // 输出字符数
    printf("Character count: %d\n", charCount);

    return 0; // 正常结束程序
}
