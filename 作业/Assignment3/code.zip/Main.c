#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <limits.h>
#include <ctype.h>

#define READ_END 0  // 定义管道的读取端
#define WRITE_END 1 // 定义管道的写入端

// 执行服务程序的函数
void executeService(const char *service, char *const args[])
{
    pid_t pid = fork(); // 创建子进程
    if (pid == 0) // 如果是子进程
    {
        execvp(service, args); // 执行指定的服务
        perror("execvp failed"); // 如果execvp调用失败，输出错误信息
        exit(EXIT_FAILURE); // 退出子进程
    }
    else if (pid > 0) // 如果是父进程
    {
        wait(NULL); // 等待子进程结束
    }
    else
    {
        perror("fork failed"); // 如果fork调用失败，输出错误信息
    }
}

int main()
{
    // 创建两个管道：pipe1用于父进程和子进程之间传递数据，pipe2用于子进程向父进程传递路径信息
    int pipe1[2], pipe2[2];
    if (pipe(pipe1) == -1 || pipe(pipe2) == -1) // 创建管道失败
    {
        perror("pipe creation failed");
        exit(EXIT_FAILURE);
    }

    pid_t pid = fork(); // 创建子进程
    if (pid == -1) // 如果fork失败
    {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) // 父进程 - producerConsumerChild
    { 
        close(pipe1[READ_END]); // 父进程关闭pipe1的读取端
        close(pipe2[WRITE_END]); // 父进程关闭pipe2的写入端

        // 读取editSource.txt文件的内容
        FILE *sourceFile = fopen("editSource.txt", "r");
        if (!sourceFile) // 文件打开失败
        {
            perror("failed to open editSource.txt");
            exit(EXIT_FAILURE);
        }

        // 获取文件大小
        fseek(sourceFile, 0, SEEK_END);
        long fileSize = ftell(sourceFile);
        fseek(sourceFile, 0, SEEK_SET);

        // 读取文件内容到内存
        char *fileContent = malloc(fileSize + 1);
        if (!fileContent) // 内存分配失败
        {
            perror("memory allocation failed");
            exit(EXIT_FAILURE);
        }
        fread(fileContent, 1, fileSize, sourceFile);
        fileContent[fileSize] = '\0'; // 确保文件内容以'\0'结尾
        fclose(sourceFile);

        // 将文件内容写入管道pipe1
        write(pipe1[WRITE_END], fileContent, strlen(fileContent));
        free(fileContent);

        // 从pipe2读取路径信息
        char pathInfo[PATH_MAX * 2 + 2];
        int bytesRead = read(pipe2[READ_END], pathInfo, sizeof(pathInfo) - 1);
        if (bytesRead <= 0) // 从管道读取失败
        {
            perror("read from pipe2 failed");
            exit(EXIT_FAILURE);
        }
        pathInfo[bytesRead] = '\0';

        // 解析路径信息
        char *countPath = strtok(pathInfo, "\n");
        char *noUpperPath = strtok(NULL, "\n");

        // 显示theCount.txt文件的内容
        FILE *countFile = fopen(countPath, "r");
        if (countFile)
        {
            char line[256];
            printf("Contents of theCount.txt:\n");
            while (fgets(line, sizeof(line), countFile)) // 逐行读取并打印
            {
                printf("%s", line);
            }
            fclose(countFile);
        }

        // 执行diff命令
        printf("\nResult of diff command:\n");
        char diffCommand[PATH_MAX * 2 + 20];
        snprintf(diffCommand, sizeof(diffCommand), "diff editSource.txt noUpper.txt");
        system(diffCommand); // 执行diff命令比较两个文件

        close(pipe1[WRITE_END]); // 关闭管道
        close(pipe2[READ_END]);
        wait(NULL); // 等待子进程结束
    }
    else // 子进程 - consumerProducerParent
    { 
        close(pipe1[WRITE_END]); // 子进程关闭pipe1的写入端
        close(pipe2[READ_END]);  // 子进程关闭pipe2的读取端

        // 从管道pipe1读取父进程传递的文本数据
        char buffer[4096];
        int bytesRead = read(pipe1[READ_END], buffer, sizeof(buffer) - 1);
        if (bytesRead <= 0) // 从管道读取失败
        {
            perror("read from pipe1 failed");
            exit(EXIT_FAILURE);
        }
        buffer[bytesRead] = '\0'; // 确保读取的文本是以'\0'结尾

        // 调用各服务程序进行统计
        char *countCharArgs[] = {"./countCharService", buffer, NULL};
        char *countWordArgs[] = {"./countWordService", buffer, NULL};
        char *countLineArgs[] = {"./countLineService", buffer, NULL};
        char *toLowerArgs[] = {"./toLowerCaseService", buffer, NULL};

        // 执行统计服务
        executeService("./countCharService", countCharArgs);
        executeService("./countWordService", countWordArgs);
        executeService("./countLineService", countLineArgs);
        executeService("./toLowerCaseService", toLowerArgs);

        // 将文本转换为小写后写入noUpper.txt
        toLowerCase(buffer);  // 转换为小写
        FILE *noUpperFile = fopen("noUpper.txt", "w");
        if (!noUpperFile) // 创建文件失败
        {
            perror("failed to create noUpper.txt");
            exit(EXIT_FAILURE);
        }
        fprintf(noUpperFile, "%s", buffer); // 将转换后的内容写入文件
        fclose(noUpperFile);

        // 创建theCount.txt并写入统计信息
        FILE *countFile = fopen("theCount.txt", "w");
        if (!countFile) // 创建文件失败
        {
            perror("failed to create theCount.txt");
            exit(EXIT_FAILURE);
        }

        // 使用修正后的统计逻辑写入文件
        fprintf(countFile, "Number of characters: %d\n", bytesRead);  // 精确字符数
        fprintf(countFile, "Number of words: %d\n", countWords(buffer));
        fprintf(countFile, "Number of lines: %d\n", countLines(buffer));
        fclose(countFile);

        // 获取文件的绝对路径
        char noUpperPath[PATH_MAX];
        char countPath[PATH_MAX];
        realpath("noUpper.txt", noUpperPath);
        realpath("theCount.txt", countPath);

        // 将路径信息写入pipe2
        char pathInfo[PATH_MAX * 2 + 2];
        snprintf(pathInfo, sizeof(pathInfo), "%s\n%s", countPath, noUpperPath);
        write(pipe2[WRITE_END], pathInfo, strlen(pathInfo));

        close(pipe1[READ_END]); // 关闭管道
        close(pipe2[WRITE_END]);
        exit(EXIT_SUCCESS); // 子进程结束
    }

    return 0; // 主程序结束
}
